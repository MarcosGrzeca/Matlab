x = (((x+3)*2)/5);

a = (5) - (c);
b = 5 ^ 3
x = (((a + 12) + (10 + 32)) > 0);

a = ((5) ^ 3) / (6 * (5 + 6))


x = ((a + 12) + (10 + 32));
x = ((a + 12) - (10 + 32));
x = ((a + 12) *  (10 + 32));
x = ((a + 12) / (10 - 32));


a = not('v')
a = teste(x, v)

x = (((x+3)*2)/5);

a = 5 - (c);
a = 5 ^ 3
x = ((a + 12) + (10 + 32));

x = ((a + 12) + (10 + 32));
x = ((a + 12) - (10 + 32));
x = ((a + 12) *  (10 + 32));
x = ((a + 12) / (10 + 32));



while i < 3
  s = s + i;
  i = i + 1;
end

x = ((a + 12) + (10 + 32));
x = (a + 12 + 10 + 32);
x = a + 12 + 10 + 32;

x = ((a + 12) + (10 + 32));

if a > b
    x = a + 10 + 32;
end

switch (n)
    case -1
        x = 5;
        k = k+1;
end

if (a > b)
    x = a + 10 + 32;
end

if a > b + c - d 
    x = a + 10 + 32;
end

a = not(x)

a = teste(te)

switch n
    case -1
        x = 5;
        k = k+1;
    case 0
        x = 1
    case 1
        x = 2;
    otherwise
        x = 5;
        switch n
            case -1
                x = 5;
                k = k+1;
            case 0
                x = 1
            case 1
                x = 2;
            otherwise
                x = 5;
        end
end

switch n
    case -1
        x = 5;
    case 0
        x = 5;
    case 1
        x = 5;
end

if ((x >= minVal) && (x <= maxVal))
    x=x+1;
elseif (x > maxVal)
    x=x+1;
elseif (x > maxVal)
    x=x+2
elseif x < maxVal
    x=x+4;
else
    x=x+3;
end


if ((x >= minVal) && (x <= maxVal))
    if ((10 + 32) > 0 && (5 > 2))
        a = v;
        x = (a + 12) + (10 + 32);
        x = ((a + 12) - (10 + 32));
        x = ((a + 12) *  (10 + 32));
        x = ((a + 12) / (10 + 32));
    end
else 
    teste = a
end

for i=0:-2:10
    x = 5
end